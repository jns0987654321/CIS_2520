#define MAXNAMESIZE 20 

typedef struct 
{
    char name[MAXNAMESIZE];
    int grade;
} Student;
