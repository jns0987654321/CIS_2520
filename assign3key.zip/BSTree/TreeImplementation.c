/*********************************************************************
 * FILE NAME: TreeImplementation.c
 * PURPOSE: Implementation of a generic Binary Search Tree ADT
 * AUTHOR: P. Matsakis (CIS2520, Assignment 3)
 * DATE: 31/10/2011
 *********************************************************************/


#include "TreeInterface.h"
#include <stdlib.h>
#include <string.h>


static TreeNode * minimum (TreeNode *N) {
	while(N->left!=NULL) N=N->left;
	return N;
}


static void destroy (TreeNode *N, Tree *T) {
	if(N!=NULL) {
		destroy(N->left,T);
		destroy(N->right,T);
		T->destroyItem(N->item);
		free(N);
	}
}


void Initialize (Tree *T,
				 void * (*copyItem) (void *, void *),
				 void (*destroyItem) (void *),
				 int (*compareItems) (void *, void *)) {
	T->root=NULL;
	T->copyItem=copyItem;
	T->destroyItem=destroyItem;
	T->compareItems=compareItems;
}


void Insert (Tree *T, void *I) {
	TreeNode *N, *P, *Q;
	
	N=malloc(sizeof(TreeNode));
	N->item=T->copyItem(NULL,I);
	N->right=NULL;
	N->left=NULL;
	P=T->root;
	Q=NULL;
	
	while(P!=NULL) {
		Q=P;
		if(T->compareItems(I,P->item)<0) P=P->left;
		else P=P->right;
	}
	
	N->parent=Q;
	if(Q==NULL) T->root=N;
	else if(T->compareItems(I,Q->item)<0) Q->left=N;
	else Q->right=N;
}


int Minimum (Tree *T, void *I) {
	TreeNode *N;
	if(T->root==NULL) return 0;
	N=minimum(T->root);
	T->current=N;
	T->copyItem(I,N->item);
	return 1;
}


int Successor (Tree *T, void *I) {
	TreeNode *N, *P;
	if(T->root==NULL) return 0;
	if((N=T->current->right)!=NULL) {
		P=minimum(N);
		T->current=P;
		T->copyItem(I,P->item);
		return 1;
	}
	N=T->current;
	P=N->parent;
	while(P!=NULL && N==P->right) {
		N=P;
		P=P->parent;
	}
	if(P==NULL) return 0;
	T->current=P;
	T->copyItem(I,P->item);
	return 1;
}


void Destroy (Tree *T) {
	destroy(T->root,T);	
}

