

typedef struct {
	char *name;
	int grade;
} Student;

