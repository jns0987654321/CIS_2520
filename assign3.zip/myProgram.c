
#include "StudentInterface.h"
#include "TreeInterface.h"
/* some code here (e.g., #include directives, static functions) */

int main (void) {
	/* some code here */
}

